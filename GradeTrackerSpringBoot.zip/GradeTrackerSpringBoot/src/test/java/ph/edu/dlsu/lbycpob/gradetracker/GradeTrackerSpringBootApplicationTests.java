package ph.edu.dlsu.lbycpob.gradetracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GradeTrackerSpringBootApplicationTests {

    @Test
    void contextLoads() {
    }

}
