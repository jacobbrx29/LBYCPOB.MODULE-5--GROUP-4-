package ph.edu.dlsu.lbycpob.gradetracker.dto;

// ============================================================
// ClassStatsResult.java
// Stores the computed class statistics that will be displayed
// on the Grade Tracker statistics webpage.
// ============================================================
public class ClassStatsResult {

    private int totalStudents;

    private String highestName;
    private double highestGrade;
    private char highestRank;

    private String lowestName;
    private double lowestGrade;
    private char lowestRank;

    private double classMean;
    private char meanRank;

    public int getTotalStudents() {
        return totalStudents;
    }

    public void setTotalStudents(int value) {
        this.totalStudents = value;
    }

    public String getHighestName() {
        return highestName;
    }

    public void setHighestName(String value) {
        this.highestName = value;
    }

    public double getHighestGrade() {
        return highestGrade;
    }

    public void setHighestGrade(double value) {
        this.highestGrade = value;
    }

    public char getHighestRank() {
        return highestRank;
    }

    public void setHighestRank(char value) {
        this.highestRank = value;
    }

    public String getLowestName() {
        return lowestName;
    }

    public void setLowestName(String value) {
        this.lowestName = value;
    }

    public double getLowestGrade() {
        return lowestGrade;
    }

    public void setLowestGrade(double value) {
        this.lowestGrade = value;
    }

    public char getLowestRank() {
        return lowestRank;
    }

    public void setLowestRank(char value) {
        this.lowestRank = value;
    }

    public double getClassMean() {
        return classMean;
    }

    public void setClassMean(double value) {
        this.classMean = value;
    }

    public char getMeanRank() {
        return meanRank;
    }

    public void setMeanRank(char value) {
        this.meanRank = value;
    }
}