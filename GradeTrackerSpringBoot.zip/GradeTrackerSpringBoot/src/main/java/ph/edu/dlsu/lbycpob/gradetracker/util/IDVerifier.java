package ph.edu.dlsu.lbycpob.gradetracker.util;

// ============================================================
// IDVerifier.java
// NOTES:
//   The original class had two layers:
//   (a) Static pure methods -- isValidID(), getIDRole(),
//       validateID(), calculateDotProduct() (NO CHANGES)
//   (b) Instance method verifyID() (REMOVED)
//       That method ran an interactive console loop; the web
//       equivalent is GET /verify + POST /verify in
//       GradeController, rendered by verify-id.html.
// ============================================================
public final class IDVerifier {

    private IDVerifier() {
    } // Prevents instantiation.

    /**
     * Returns true if the ID passes all three validation checks:
     * exactly eight characters, digits only, and a dot product
     * divisible by eleven.
     *
     * @param idNumber ID number to validate
     * @return true when the ID number is valid; otherwise, false
     */
    public static boolean isValidID(String idNumber) {
        if (idNumber == null
                || idNumber.length() != GradeConstants.ID_LENGTH) {
            return false;
        }

        if (!idNumber.chars().allMatch(Character::isDigit)) {
            return false;
        }

        return calculateDotProduct(idNumber)
                % GradeConstants.ID_DIVISOR == 0;
    }

    /**
     * Determines whether a valid ID belongs to a faculty member
     * or a student.
     *
     * @param idNumber valid ID number
     * @return "faculty" or "student"
     */
    public static String getIDRole(String idNumber) {
        int quotient = calculateDotProduct(idNumber)
                / GradeConstants.ID_DIVISOR;

        return quotient >= GradeConstants.FACULTY_THRESHOLD
                ? "faculty"
                : "student";
    }

    /**
     * Returns a readable message describing the ID validation result.
     *
     * @param idNumber ID number to validate
     * @return validation result message
     */
    public static String validateID(String idNumber) {
        if (idNumber == null
                || idNumber.length() != GradeConstants.ID_LENGTH) {
            return "Invalid ID number. Please enter "
                    + GradeConstants.ID_LENGTH + " digits.";
        }

        if (!idNumber.chars().allMatch(Character::isDigit)) {
            return "Invalid ID number. All characters must be digits.";
        }

        if (!isValidID(idNumber)) {
            return "Invalid ID number. Dot product must be divisible by "
                    + GradeConstants.ID_DIVISOR + ".";
        }

        return "Valid " + getIDRole(idNumber) + " ID number.";
    }

    /**
     * Calculates the dot product of the ID digits using descending
     * weights from eight to one.
     *
     * @param idNumber eight-digit ID number
     * @return calculated dot-product sum
     */
    private static int calculateDotProduct(String idNumber) {
        final int[] weights = {8, 7, 6, 5, 4, 3, 2, 1};
        int sum = 0;

        for (int index = 0; index < idNumber.length(); index++) {
            int digit = Character.getNumericValue(idNumber.charAt(index));
            sum += digit * weights[index];
        }

        return sum;
    }
}