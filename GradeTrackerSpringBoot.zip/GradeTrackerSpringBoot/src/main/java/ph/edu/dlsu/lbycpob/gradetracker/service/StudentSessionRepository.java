package ph.edu.dlsu.lbycpob.gradetracker.service;

import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.SessionScope;
import ph.edu.dlsu.lbycpob.gradetracker.model.Student;
import ph.edu.dlsu.lbycpob.gradetracker.util.GradeConstants;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

// ============================================================
// StudentSessionRepository.java
// NOTE:
//   The original StudentRepository used a fixed-size Student[]
//   array and a manual counter.
//
//   In the web version, student records must remain available
//   across multiple HTTP requests while staying private to one
//   browser session. @SessionScope creates one repository for
//   each browser session.
//
//   ArrayList replaces the fixed-size array, while the original
//   maximum student limit is still enforced.
// ============================================================
@Component
@SessionScope
public class StudentSessionRepository {

    private final List<Student> students = new ArrayList<>();

    /**
     * Adds a student when the repository has available space.
     *
     * @param student student record to add
     * @return true if the student was added; otherwise, false
     */
    public boolean addStudent(Student student) {
        if (students.size() >= GradeConstants.MAX_STUDENTS) {
            return false;
        }

        students.add(student);
        return true;
    }

    /**
     * Returns a read-only view of all stored students.
     *
     * @return unmodifiable student list
     */
    public List<Student> getAllStudents() {
        return Collections.unmodifiableList(students);
    }

    /**
     * Returns the student found at the specified index.
     *
     * @param index zero-based position of the student
     * @return the student, or null when the index is invalid
     */
    public Student getStudent(int index) {
        if (index < 0 || index >= students.size()) {
            return null;
        }

        return students.get(index);
    }

    /**
     * Returns the number of currently stored students.
     *
     * @return student count
     */
    public int getCount() {
        return students.size();
    }

    /**
     * Removes all students from the current browser session.
     */
    public void clear() {
        students.clear();
    }

    /**
     * Checks whether the repository has reached its limit.
     *
     * @return true when the maximum number of students is reached
     */
    public boolean isFull() {
        return students.size() >= GradeConstants.MAX_STUDENTS;
    }
}