package ph.edu.dlsu.lbycpob.gradetracker.dto;

import jakarta.validation.constraints.NotBlank;

// ============================================================
// IDVerifyFormDTO.java
// Captures the ID entered in the verification webpage.
// ============================================================
public class IDVerifyFormDTO {

    @NotBlank(message = "Please enter an ID number.")
    private String idNumber;

    public String getIdNumber() {
        return idNumber;
    }

    public void setIdNumber(String id) {
        this.idNumber = id;
    }
}