package ph.edu.dlsu.lbycpob.gradetracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GradeTrackerSpringBootApplication {

    public static void main(String[] args) {
        SpringApplication.run(GradeTrackerSpringBootApplication.class, args);
    }

}
