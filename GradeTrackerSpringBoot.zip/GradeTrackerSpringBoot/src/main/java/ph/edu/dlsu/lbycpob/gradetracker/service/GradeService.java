package ph.edu.dlsu.lbycpob.gradetracker.service;

import org.springframework.stereotype.Service;
import ph.edu.dlsu.lbycpob.gradetracker.dto.StudentFormDTO;
import ph.edu.dlsu.lbycpob.gradetracker.model.Student;
import ph.edu.dlsu.lbycpob.gradetracker.util.GradeCalculator;
import ph.edu.dlsu.lbycpob.gradetracker.util.IDVerifier;

// ============================================================
// GradeService.java
// PURPOSE:
//   Contains the Grade Tracker's business logic.
//
//   The web form sends its data through StudentFormDTO.
//   This service calculates the student's grades and creates
//   the final Student object used by the application.
// ============================================================
@Service
public class GradeService {

    /**
     * Converts a validated StudentFormDTO into a fully computed
     * Student object.
     *
     * @param dto student information and scores from the web form
     * @return a Student object containing the calculated grades
     */
    public Student buildStudent(StudentFormDTO dto) {
        double[] moduleScores = {
                dto.getModule1(),
                dto.getModule2(),
                dto.getModule3(),
                dto.getModule4(),
                dto.getModule5()
        };

        // The five module scores make up the Laboratory Performance grade.
        double labPerformance =
                GradeCalculator.computeAverage(moduleScores);

        double rawGrade = GradeCalculator.computeRawGrade(
                labPerformance,
                dto.getClassParticipation(),
                dto.getTeacherEvaluation(),
                dto.getPracticalExam(),
                dto.getProject()
        );

        String numericGrade =
                GradeCalculator.assignNumericGrade(rawGrade);

        char letterRank =
                GradeCalculator.assignLetterRank(rawGrade);

        return new Student(
                dto.getName(),
                dto.getIdNumber(),
                rawGrade,
                numericGrade,
                letterRank
        );
    }

    /**
     * Validates an entered ID number and returns its result message.
     *
     * @param idNumber ID number entered by the user
     * @return the ID validation result
     */
    public String verifyIdNumber(String idNumber) {
        String cleanedId = idNumber == null ? "" : idNumber.trim();
        return IDVerifier.validateID(cleanedId);
    }
}