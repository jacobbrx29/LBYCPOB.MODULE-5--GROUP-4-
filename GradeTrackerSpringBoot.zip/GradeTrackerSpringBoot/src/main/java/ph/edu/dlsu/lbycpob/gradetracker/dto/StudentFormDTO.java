package ph.edu.dlsu.lbycpob.gradetracker.dto;

import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

// ============================================================
// StudentFormDTO.java
// Mapping to the original desktop prompts:
//   name                 <- inputName()
//   idNumber             <- inputIdNumber()
//   module1 to module5   <- inputLabPerformance()
//   remaining components <- inputComponentScore()
// ============================================================
public class StudentFormDTO {

    // Student identity fields
    @NotBlank(message = "Student name is required.")
    private String name;

    @NotBlank(message = "ID number is required.")
    @Size(min = 8, max = 8,
            message = "ID number must be exactly 8 digits.")
    @Pattern(regexp = "\\d{8}",
            message = "ID number must contain exactly 8 digits.")
    private String idNumber;

    // Five module scores used for Laboratory Performance
    @DecimalMin(value = "0.0",
            message = "Module 1 score must be 0 - 100.")
    @DecimalMax(value = "100.0",
            message = "Module 1 score must be 0 - 100.")
    private double module1;

    @DecimalMin(value = "0.0",
            message = "Module 2 score must be 0 - 100.")
    @DecimalMax(value = "100.0",
            message = "Module 2 score must be 0 - 100.")
    private double module2;

    @DecimalMin(value = "0.0",
            message = "Module 3 score must be 0 - 100.")
    @DecimalMax(value = "100.0",
            message = "Module 3 score must be 0 - 100.")
    private double module3;

    @DecimalMin(value = "0.0",
            message = "Module 4 score must be 0 - 100.")
    @DecimalMax(value = "100.0",
            message = "Module 4 score must be 0 - 100.")
    private double module4;

    @DecimalMin(value = "0.0",
            message = "Module 5 score must be 0 - 100.")
    @DecimalMax(value = "100.0",
            message = "Module 5 score must be 0 - 100.")
    private double module5;

    // Other grade components
    @DecimalMin(value = "0.0",
            message = "Class Participation must be 0 - 100.")
    @DecimalMax(value = "100.0",
            message = "Class Participation must be 0 - 100.")
    private double classParticipation;

    @DecimalMin(value = "0.0",
            message = "Teacher's Evaluation must be 0 - 100.")
    @DecimalMax(value = "100.0",
            message = "Teacher's Evaluation must be 0 - 100.")
    private double teacherEvaluation;

    @DecimalMin(value = "0.0",
            message = "Practical Exam must be 0 - 100.")
    @DecimalMax(value = "100.0",
            message = "Practical Exam must be 0 - 100.")
    private double practicalExam;

    @DecimalMin(value = "0.0",
            message = "Project must be 0 - 100.")
    @DecimalMax(value = "100.0",
            message = "Project must be 0 - 100.")
    private double project;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIdNumber() {
        return idNumber;
    }

    public void setIdNumber(String idNumber) {
        this.idNumber = idNumber;
    }

    public double getModule1() {
        return module1;
    }

    public void setModule1(double module1) {
        this.module1 = module1;
    }

    public double getModule2() {
        return module2;
    }

    public void setModule2(double module2) {
        this.module2 = module2;
    }

    public double getModule3() {
        return module3;
    }

    public void setModule3(double module3) {
        this.module3 = module3;
    }

    public double getModule4() {
        return module4;
    }

    public void setModule4(double module4) {
        this.module4 = module4;
    }

    public double getModule5() {
        return module5;
    }

    public void setModule5(double module5) {
        this.module5 = module5;
    }

    public double getClassParticipation() {
        return classParticipation;
    }

    public void setClassParticipation(double classParticipation) {
        this.classParticipation = classParticipation;
    }

    public double getTeacherEvaluation() {
        return teacherEvaluation;
    }

    public void setTeacherEvaluation(double teacherEvaluation) {
        this.teacherEvaluation = teacherEvaluation;
    }

    public double getPracticalExam() {
        return practicalExam;
    }

    public void setPracticalExam(double practicalExam) {
        this.practicalExam = practicalExam;
    }

    public double getProject() {
        return project;
    }

    public void setProject(double project) {
        this.project = project;
    }
}