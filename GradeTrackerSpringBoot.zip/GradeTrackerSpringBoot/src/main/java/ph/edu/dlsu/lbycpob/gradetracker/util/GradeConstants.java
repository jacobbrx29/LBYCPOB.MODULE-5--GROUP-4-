package ph.edu.dlsu.lbycpob.gradetracker.util;

// ============================================================
// GradeConstants.java
// NOTE:
//   This class stores the fixed configuration values used by
//   the Grade Tracker. The constants have no input/output
//   dependency and can be reused by the other application layers.
// ============================================================
public final class GradeConstants {

    /**
     * Prevents objects of this utility class from being created.
     */
    private GradeConstants() {
    }

    public static final int MAX_STUDENTS = 20;
    public static final double MIN_SCORE = 0.0;
    public static final double MAX_SCORE = 100.0;
    public static final int NUM_MODULES = 5;

    public static final int ID_LENGTH = 8;
    public static final int ID_DIVISOR = 11;
    public static final int FACULTY_THRESHOLD = 16;

    // Grade-component weights must have a total of 1.0.
    public static final double LAB_WEIGHT = 0.40;
    public static final double PARTICIPATION_WEIGHT = 0.05;
    public static final double TEACHER_WEIGHT = 0.05;
    public static final double EXAM_WEIGHT = 0.20;
    public static final double PROJECT_WEIGHT = 0.30;
}