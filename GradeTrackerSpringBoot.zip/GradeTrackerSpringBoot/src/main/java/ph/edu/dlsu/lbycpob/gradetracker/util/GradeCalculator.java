package ph.edu.dlsu.lbycpob.gradetracker.util;

// ============================================================
// GradeCalculator.java
// NOTE: No changes required from the desktop app.
// All methods are static pure functions with no IO dependency.
// Called identically from GradeService:
// GradeCalculator.computeRawGrade(...)
// GradeCalculator.assignNumericGrade(avg)
// GradeCalculator.assignLetterRank(avg)
// GradeCalculator.getRemarks(grade)
// ============================================================
public final class GradeCalculator {

    private GradeCalculator() {
    } // Prevents instantiation.

    /**
     * Calculates the arithmetic mean of an array of scores.
     *
     * @param scores array containing the scores
     * @return the arithmetic mean, or 0.0 if the array is null or empty
     */
    public static double computeAverage(double[] scores) {
        if (scores == null || scores.length == 0) {
            return 0.0;
        }

        double sum = 0.0;

        for (double score : scores) {
            sum += score;
        }

        return sum / scores.length;
    }

    /**
     * Calculates the weighted raw grade using the five grade components.
     *
     * @param labPerformance average laboratory performance score
     * @param classParticipation class participation score
     * @param teacherEvaluation teacher's evaluation score
     * @param practicalExam practical examination score
     * @param project project score
     * @return the weighted raw grade rounded to two decimal places
     */
    public static double computeRawGrade(
            double labPerformance,
            double classParticipation,
            double teacherEvaluation,
            double practicalExam,
            double project) {

        double rawGrade =
                (labPerformance * GradeConstants.LAB_WEIGHT)
                        + (classParticipation * GradeConstants.PARTICIPATION_WEIGHT)
                        + (teacherEvaluation * GradeConstants.TEACHER_WEIGHT)
                        + (practicalExam * GradeConstants.EXAM_WEIGHT)
                        + (project * GradeConstants.PROJECT_WEIGHT);

        return Math.round(rawGrade * 100.0) / 100.0;
    }

    /**
     * Converts a raw grade into its corresponding DLSU numeric grade.
     *
     * @param average raw grade average
     * @return the numeric grade as a String
     */
    public static String assignNumericGrade(double average) {
        if (average >= 96.0) {
            return "4.0";
        } else if (average >= 92.0) {
            return "3.5";
        } else if (average >= 88.0) {
            return "3.0";
        } else if (average >= 83.0) {
            return "2.5";
        } else if (average >= 78.0) {
            return "2.0";
        } else if (average >= 74.0) {
            return "1.5";
        } else if (average >= 70.0) {
            return "1.0";
        } else {
            return "0.0";
        }
    }

    /**
     * Converts a raw grade into its corresponding letter rank.
     *
     * @param average raw grade average
     * @return the letter rank
     */
    public static char assignLetterRank(double average) {
        if (average >= 96.0) {
            return 'S';
        } else if (average >= 92.0) {
            return 'A';
        } else if (average >= 88.0) {
            return 'B';
        } else if (average >= 83.0) {
            return 'C';
        } else if (average >= 78.0) {
            return 'D';
        } else if (average >= 74.0) {
            return 'E';
        } else if (average >= 70.0) {
            return 'P';
        } else {
            return 'F';
        }
    }

    /**
     * Returns the appropriate remark for a numeric grade.
     *
     * @param grade numeric grade as a String
     * @return the corresponding grade remark
     */
    public static String getRemarks(String grade) {
        return switch (grade.trim()) {
            case "4.0" -> "Excellent";
            case "3.5" -> "Superior";
            case "3.0" -> "Very Good";
            case "2.5" -> "Good";
            case "2.0" -> "Satisfactory";
            case "1.5" -> "Fair";
            case "1.0" -> "Poor/Passed";
            case "0.0" -> "Failed";
            default -> "Unknown";
        };
    }

    /**
     * Returns the appropriate remark for a letter rank.
     *
     * @param rank letter rank
     * @return the corresponding grade remark
     */
    public static String getRemarks(char rank) {
        return switch (Character.toUpperCase(rank)) {
            case 'S' -> "Excellent";
            case 'A' -> "Superior";
            case 'B' -> "Very Good";
            case 'C' -> "Good";
            case 'D' -> "Satisfactory";
            case 'E' -> "Fair";
            case 'P' -> "Poor/Passed";
            case 'F' -> "Failed";
            default -> "Unknown";
        };
    }
}