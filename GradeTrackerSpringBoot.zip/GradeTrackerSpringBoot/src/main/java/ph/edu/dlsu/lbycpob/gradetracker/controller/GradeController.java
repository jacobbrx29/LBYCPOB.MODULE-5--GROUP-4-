package ph.edu.dlsu.lbycpob.gradetracker.controller;

import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import ph.edu.dlsu.lbycpob.gradetracker.dto.ClassStatsResult;
import ph.edu.dlsu.lbycpob.gradetracker.dto.IDVerifyFormDTO;
import ph.edu.dlsu.lbycpob.gradetracker.dto.StudentFormDTO;
import ph.edu.dlsu.lbycpob.gradetracker.model.Student;
import ph.edu.dlsu.lbycpob.gradetracker.service.GradeService;
import ph.edu.dlsu.lbycpob.gradetracker.service.StudentSessionRepository;
import ph.edu.dlsu.lbycpob.gradetracker.util.GradeCalculator;
import ph.edu.dlsu.lbycpob.gradetracker.util.GradeConstants;
import ph.edu.dlsu.lbycpob.gradetracker.util.IDVerifier;

import java.util.List;

// ============================================================
// GradeController.java
// NOTES:
//   The original Grade Tracker used a console menu.
//
//   In the web version, each menu action has its own URL:
//   GET  /                - Home page
//   GET  /students/enter  - Student entry form
//   POST /students/add    - Add a student
//   POST /students/clear  - Clear all student records
//   GET  /report          - Grade report
//   GET  /stats           - Class statistics
//   GET  /verify          - ID verification form
//   POST /verify          - Process an ID verification
// ============================================================
@Controller
public class GradeController {

    private final StudentSessionRepository repository;
    private final GradeService gradeService;

    /**
     * Creates the controller using constructor dependency injection.
     *
     * @param repository session-based student repository
     * @param gradeService Grade Tracker business logic service
     */
    public GradeController(StudentSessionRepository repository,
                           GradeService gradeService) {
        this.repository = repository;
        this.gradeService = gradeService;
    }

    /**
     * Displays the main Grade Tracker menu.
     *
     * @param model values sent to the home page
     * @return home template name
     */
    @GetMapping("/")
    public String home(Model model) {
        model.addAttribute("studentCount", repository.getCount());
        model.addAttribute("maxStudents", GradeConstants.MAX_STUDENTS);
        model.addAttribute("repoFull", repository.isFull());

        return "index";
    }

    /**
     * Displays the student entry form and current student list.
     *
     * @param model values sent to the student entry page
     * @return student entry template name
     */
    @GetMapping("/students/enter")
    public String showEntryForm(Model model) {
        if (!model.containsAttribute("studentForm")) {
            model.addAttribute("studentForm", new StudentFormDTO());
        }

        addEntryPageAttributes(model);
        return "enter-students";
    }

    /**
     * Validates and stores one submitted student record.
     *
     * @param form submitted student data
     * @param bindingResult form validation results
     * @param redirectAttributes messages kept after redirecting
     * @param model values sent back when validation fails
     * @return redirect or template destination
     */
    @PostMapping("/students/add")
    public String addStudent(
            @Valid @ModelAttribute("studentForm") StudentFormDTO form,
            BindingResult bindingResult,
            RedirectAttributes redirectAttributes,
            Model model) {

        // Perform the semantic ID check after field validation succeeds.
        if (!bindingResult.hasErrors()) {
            String idResult = IDVerifier.validateID(form.getIdNumber());

            if (idResult.startsWith("Invalid")) {
                bindingResult.rejectValue(
                        "idNumber",
                        "id.invalid",
                        idResult
                );
            }
        }

        if (bindingResult.hasErrors()) {
            addEntryPageAttributes(model);
            return "enter-students";
        }

        if (repository.isFull()) {
            redirectAttributes.addFlashAttribute(
                    "errorMessage",
                    "Maximum of " + GradeConstants.MAX_STUDENTS
                            + " students reached. Clear data to start over."
            );

            return "redirect:/students/enter";
        }

        Student student = gradeService.buildStudent(form);
        repository.addStudent(student);

        redirectAttributes.addFlashAttribute(
                "successMessage",
                "Student \"" + student.getName()
                        + "\" added successfully."
        );

        return "redirect:/students/enter";
    }

    /**
     * Clears all student records from the current browser session.
     *
     * @param redirectAttributes message kept after redirecting
     * @return redirect to the home page
     */
    @PostMapping("/students/clear")
    public String clearStudents(
            RedirectAttributes redirectAttributes) {

        repository.clear();

        redirectAttributes.addFlashAttribute(
                "successMessage",
                "All student data cleared."
        );

        return "redirect:/";
    }

    /**
     * Displays the complete student grade report.
     *
     * @param model values sent to the report page
     * @return report template name
     */
    @GetMapping("/report")
    public String viewReport(Model model) {
        List<Student> students = repository.getAllStudents();

        model.addAttribute("students", students);
        model.addAttribute("hasData", !students.isEmpty());

        return "report";
    }

    /**
     * Calculates and displays the class statistics.
     *
     * @param model values sent to the statistics page
     * @return statistics template name
     */
    @GetMapping("/stats")
    public String viewStats(Model model) {
        List<Student> students = repository.getAllStudents();

        if (students.isEmpty()) {
            model.addAttribute("hasData", false);
            return "stats";
        }

        double highestGrade = students.get(0).getRawGrade();
        double lowestGrade = students.get(0).getRawGrade();
        double gradeSum = students.get(0).getRawGrade();

        int highestIndex = 0;
        int lowestIndex = 0;

        // Start from index 1 because the first student was used for seeding.
        for (int index = 1; index < students.size(); index++) {
            double currentGrade = students.get(index).getRawGrade();
            gradeSum += currentGrade;

            if (currentGrade > highestGrade) {
                highestGrade = currentGrade;
                highestIndex = index;
            }

            if (currentGrade < lowestGrade) {
                lowestGrade = currentGrade;
                lowestIndex = index;
            }
        }

        double classMean = gradeSum / students.size();

        ClassStatsResult stats = new ClassStatsResult();
        stats.setTotalStudents(students.size());

        stats.setHighestName(
                students.get(highestIndex).getName());
        stats.setHighestGrade(highestGrade);
        stats.setHighestRank(
                GradeCalculator.assignLetterRank(highestGrade));

        stats.setLowestName(
                students.get(lowestIndex).getName());
        stats.setLowestGrade(lowestGrade);
        stats.setLowestRank(
                GradeCalculator.assignLetterRank(lowestGrade));

        stats.setClassMean(classMean);
        stats.setMeanRank(
                GradeCalculator.assignLetterRank(classMean));

        model.addAttribute("stats", stats);
        model.addAttribute("hasData", true);

        return "stats";
    }

    /**
     * Displays the ID verification form.
     *
     * @param model values sent to the verification page
     * @return ID verification template name
     */
    @GetMapping("/verify")
    public String showVerifyForm(Model model) {
        if (!model.containsAttribute("verifyForm")) {
            model.addAttribute(
                    "verifyForm",
                    new IDVerifyFormDTO()
            );
        }

        return "verify-id";
    }

    /**
     * Processes the entered ID and displays its validation result.
     *
     * @param form submitted ID form
     * @param bindingResult form validation results
     * @param redirectAttributes result kept after redirecting
     * @return redirect or verification template destination
     */
    @PostMapping("/verify")
    public String verifyId(
            @Valid @ModelAttribute("verifyForm") IDVerifyFormDTO form,
            BindingResult bindingResult,
            RedirectAttributes redirectAttributes) {

        if (bindingResult.hasErrors()) {
            return "verify-id";
        }

        String cleanedId = form.getIdNumber().trim();
        String result = gradeService.verifyIdNumber(cleanedId);

        redirectAttributes.addFlashAttribute(
                "verifyResult", result);
        redirectAttributes.addFlashAttribute(
                "verifiedId", cleanedId);
        redirectAttributes.addFlashAttribute(
                "isValid", !result.startsWith("Invalid"));
        redirectAttributes.addFlashAttribute(
                "verifyForm", new IDVerifyFormDTO());

        return "redirect:/verify";
    }

    /**
     * Adds the common values needed by the student entry page.
     *
     * @param model values sent to the student entry template
     */
    private void addEntryPageAttributes(Model model) {
        model.addAttribute(
                "students", repository.getAllStudents());
        model.addAttribute(
                "studentCount", repository.getCount());
        model.addAttribute(
                "maxStudents", GradeConstants.MAX_STUDENTS);
        model.addAttribute(
                "repoFull", repository.isFull());
        model.addAttribute(
                "numModules", GradeConstants.NUM_MODULES);
        model.addAttribute(
                "minScore", GradeConstants.MIN_SCORE);
        model.addAttribute(
                "maxScore", GradeConstants.MAX_SCORE);
    }
}